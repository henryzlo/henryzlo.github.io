package cs310;

/**
 * cs310/Dynamic.java
 *
 * Kimmy Lin, Apr. 2003
 */
 
import edu.umb.cs.game.*;

import java.util.Iterator;
import java.util.Map;
import java.util.HashMap;

/**
 * Backtracking ComputerPlayer chooses the best move
 * by recursively exploring the entire Game tree below
 * the current position.
 */
  
public class Dynamic extends ComputerPlayer
{
    private Map<Game,Integer> gVals;
    /**
     * Constructor.
     */
    public Dynamic()
    {
	super("dynamic backtracking findbest");
	gVals = new HashMap<Game,Integer>();
    }

    /**
     * Find the best move for a Game based on the
     * game's current position.
     * @param the game
     * @return the move for the current player of the game
     */
    public Move findbest(Game g) throws GameException
    {
	try {
	    boolean max;
	    int bestVal;

	    // if first player, then find the max value
	    // otherwise find the min value
	    if (g.whoseTurn() == Game.FIRST_PLAYER) {
		max = true;
		bestVal = Integer.MIN_VALUE;  // running max, starts at bottom
	    } else {
		max = false;
		bestVal = Integer.MAX_VALUE;
	    }

	    Move bestMove = null;
	    Iterator<Move> moves = g.getMoves();

	    while (moves.hasNext()) {
		int value;
		Move m = moves.next();
		Game cp = g.copy();
		cp.make(m);
		value = getValue(cp);
		System.out.println("val = "+value);
		if ((max && value >= bestVal) || (!max && value <= bestVal)) {
		    bestVal = value;
		    bestMove = m;
		}
	    }
	    return bestMove;
	} 
	catch (Exception e) {
	    throw new GameException (e.getMessage());
	}
    }

    /**
     * Helper recursive function for bestmove(). Find the
     * value of the game recursively.
     * 
     * @param the game.
     * @return the value of the game.
     */
    private int getValue(Game g) throws GameException
    {
	// return immediately if game is over already
	if (g.winner() == Game.FIRST_PLAYER)
	    return 1;
	else if (g.winner() == Game.SECOND_PLAYER)
	    return -1;
	else if (g.winner() == Game.DRAW)
	    return 0;

	boolean max;
	int bestVal;

	// added for Dynamic--try for previously-calc'd value
	Integer val = (Integer) gVals.get(g);
	if (val != null) {
	    return val.intValue();
	}
	
	// if first player, then find the max value
	// otherwise find the min value
	if (g.whoseTurn() == Game.FIRST_PLAYER) {
	    max = true;
	    bestVal = Integer.MIN_VALUE;  // running max, starts at bottom
	} else {
	    max = false;
	    bestVal = Integer.MAX_VALUE;
	}

	Iterator<Move> moves = g.getMoves();

	while (moves.hasNext()) {
	    int value;
	    Move m = moves.next();
	    Game cp = g.copy();
	    cp.make(m);
	    value = getValue(cp);
	    if ((max && value >= bestVal) || (!max && value <= bestVal)) {
		bestVal = value;
	    }
	}
	// added for Dynamic--
	Game cp = g.copy();  // make sure have stable copy in Map
	gVals.put(cp, new Integer(bestVal));
	return bestVal;
    }
}
