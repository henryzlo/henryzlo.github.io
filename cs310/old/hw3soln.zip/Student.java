import weiss.util.Comparator;
import weiss.util.Collection;
import weiss.util.Collections;
import weiss.util.Iterator;
import weiss.util.List;
import weiss.util.Set;
import weiss.util.ArrayList;
import weiss.util.LinkedList;
import weiss.util.TreeSet;
import weiss.util.HashSet;

/**
 * Illustrates use of hashCode/equals for a user-defined class. Also illustrates
 * the compareTo function. Students are ordered on basis of name only.
 */
class SimpleStudent implements Comparable<SimpleStudent> {
	private String name;
	private int id;
	// the following could be a Set
	private List<Book> books = new ArrayList<Book>();

	public SimpleStudent(String n, int i) {
		name = n;
		id = i;
	}

	public void addBook(long isbn, String title) {
		books.add(new Book(isbn, title));
	}

	public boolean hasBook(long isbn) {
		return books.contains(new Book(isbn));
	}

	public String toString() {
		return name + " " + id;
	}

	public boolean equals(Object rhs) {
		if (rhs == null || getClass() != rhs.getClass())
			return false;

		SimpleStudent other = (SimpleStudent) rhs;
		return name.equals(other.name);
	}

	public int compareTo(SimpleStudent other) {
		return name.compareTo(other.name);
	}

	public int hashCode() {
		return name.hashCode();
	}

	private static class Book {
		private long isbn;
		private String title;

		public Book(long isbn, String title) {
			this.isbn = isbn;
			this.title = title;
		}

		public Book(long isbn) {
			this.isbn = isbn;
			this.title = null;
		}

		public long getIsbn() {
			return isbn;
		}

		public String getTitle() {
			return title;
		}

		// needed for contains call inside hasBook--
		public boolean equals(Object rhs) {
			if (rhs == null || getClass() != rhs.getClass())
				return false;

			Book other = (Book) rhs;
			return isbn == other.isbn;
		}

		// should be supplied if equals is supplied--
		public int hashCode() {
			return new Long(isbn).hashCode();
		}
	}
}
