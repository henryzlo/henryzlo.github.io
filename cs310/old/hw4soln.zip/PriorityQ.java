import java.util.Map;
import java.util.TreeMap;
import java.util.Set;
import java.util.Iterator;

public class PriorityQ1<T>
{
    Map<T,Integer> map;
    int size;  // not really needed, since size() not implemented.
    
    /* constructor of the PriorityQ*/
    public PriorityQ1()
    {
        map = new TreeMap<T,Integer>();
        size = 0;
    } 

    //Inserts the specified element into this priority queue. 
    boolean add(T x)
    {
        if(map.containsKey(x)){
            int multiplicity = map.get(x);
            multiplicity++;
	    map.put(x, multiplicity);
            size++;
        }
        else{
            map.put(x, 1);
            size++;
        }
        return true;
    }

    // Retrieves and removes the head of this queue.     
    T remove()
    {
        Set<T> keys = map.keySet();
        Iterator<T> itr = keys.iterator();
        if(itr.hasNext()){
            T key = itr.next();
            int multiplicity = map.get(key);
            if(multiplicity == 1 )
                map.remove(key);
            else{
                multiplicity--;
		map.put(key, multiplicity);
            }
            size--;
            return key;
        }
        return null;
    }
    
    boolean isEmpty()
    {
        return size == 0;
    }
    // just a quick test
    public static void main(String[] args)
    {
	PriorityQ1<Integer> pq = new PriorityQ1<Integer>();
	pq.add(1);
	pq.add(3);
	pq.add(2);
	pq.add(1);
	while (!pq.isEmpty()) {
	    int x = pq.remove();
	System.out.println("from pq: "+ x);
	}
    }
}
