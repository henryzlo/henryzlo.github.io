/* LineUsageData.java
  Handle one line's data, using a SLL
  */

public class LineUsageData {
	private SinglyLinkedList<Usage> data;

	public LineUsageData() {
		data = new SinglyLinkedList<Usage>();
	}

	// add one sighting of a use on this line
	public void addObservation(String username) {
		Usage user;
		boolean found = false;

		// Go through linked list, searching for a specific user
		// Once found, alter users count through Usage API
		// and break out of while loop.
		for (int i = 0; i < data.size(); i++) {
			user = (Usage) data.get(i);
			if (user.getUser().equals(username)) {
				user.setCount(user.getCount() + 1);
				found = true;
			}
			if (found)
				break;
		}
		// If we never found that user in the loop, create and add one
		if (!found) {
			user = new Usage(username);
			data.add(user);
		}
	}

	// find the user with the most sightings on this line
	public Usage findMaxUsage() {
		Usage user;
		Usage record = new Usage("<NONE>");
		record.setCount(0); // init running max
		// Go through linked list and there is a new high login
		// count found, update record.
		for (int i = 0; i < data.size(); i++) {
			user = (Usage) data.get(i);
			if (user.getCount() > record.getCount()) {
				record = user;
			}
		}
		return record;
	}
}
