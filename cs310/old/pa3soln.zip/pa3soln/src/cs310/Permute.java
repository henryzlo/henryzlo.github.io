package cs310;

import java.util.Set;
import java.util.TreeSet;
/**
 * @author Joseph P. Cohen, then edited by Betty O'Neil for class solutions
 *
 */

public class Permute {
	public static void main(String[] args) {
        if (args.length != 1)
        {
                System.out.println("Usage: java cs310.Permute str");
                return;
        }
		Set<String> results = permute(args[0]);
		System.out.println(results);
	}
	
    /**
    *
    * @param str that should be permuted
    * @return a set of permutations
    */

	public static Set<String> permute(String str) {
		StringBuffer buff;
		Set<String> results = new TreeSet<String>();
		if (str.length() == 1)// base case of one char
		{
			results.add(str);
			return results;
		}

		buff = new StringBuffer(str);
		char ch = buff.charAt(0); // take the first character
		// find all permutations without the first character
		Set<String> subStrings = permute(buff.deleteCharAt(0).toString());
		// fix up the substrings by adding ch at all possible positions
		for (String sub : subStrings) {
			for (int i = 0; i <= sub.length(); i++) {
				StringBuffer subBuff = new StringBuffer(sub);
				// insert works even for position at end of string 
				results.add(subBuff.insert(i, ch).toString());//
			}
		}
		return results;
	}

}
