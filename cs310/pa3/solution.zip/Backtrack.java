package cs310;

/**
 * cs310/hw6/Backtrack.java
 *
 * Kimmy Lin, Apr. 2003
 */
 
import java.util.Iterator;

import edu.umb.cs.game.*;

/**
 * Backtracking ComputerPlayer chooses the best move
 * by recursively exploring the entire Game tree below
 * the current position.
 */
  
public class Backtrack extends ComputerPlayer
{
    /**
     * Constructor.
     */
    public Backtrack()
    {
	super("backtracking findbest");
    }

    /**
     * Find the best move for a Game based on the
     * game's current position.
     * @param the game
     * @return the move for the current player of the game
     */
    public Move findbest(Game g) throws GameException
    {
	try {
	    boolean max;
	    int bestVal;

	    // if first player, then find the max value
	    // otherwise find the min value
	    if (g.whoseTurn() == Game.FIRST_PLAYER) {
		max = true;
		bestVal = Integer.MIN_VALUE;  // running max, starts at bottom
	    } else {
		max = false;
		bestVal = Integer.MAX_VALUE;
	    }

	    Move bestMove = null;
	    Iterator<Move> moves = g.getMoves();

	    while (moves.hasNext()) {
		int value;
		Move m = moves.next();
		Game cp = g.copy();
		cp.make(m);
		value = getValue(cp);
		System.out.println("val = "+value);
		if ((max && value >= bestVal) || (!max && value <= bestVal)) {
		    bestVal = value;
		    bestMove = m;
		}
	    }
	    return bestMove;
	} 
	catch (Exception e) {
	    throw new GameException (e.getMessage());
	}
    }

    /**
     * Helper recursive function for bestmove(). Find the
     * value of the game recursively.
     * 
     * @param the game.
     * @return the value of the game.
     */
    private int getValue(Game g) throws GameException
    {
	// return immediately if game is over already
	if (g.winner() == Game.FIRST_PLAYER)
	    return 1;
	else if (g.winner() == Game.SECOND_PLAYER)
	    return -1;
	else if (g.winner() == Game.DRAW)
	    return 0;

	boolean max;
	int bestVal;

	// if first player, then find the max value
	// otherwise find the min value
	if (g.whoseTurn() == Game.FIRST_PLAYER) {
	    max = true;
	    bestVal = Integer.MIN_VALUE;  // running max, starts at bottom
	} else {
	    max = false;
	    bestVal = Integer.MAX_VALUE;
	}

	Iterator<Move> moves = g.getMoves();

	while (moves.hasNext()) {
	    int value;
	    Move m = moves.next();
	    Game cp = g.copy();
	    cp.make(m);
	    value = getValue(cp);
	    if ((max && value >= bestVal) || (!max && value <= bestVal)) {
		bestVal = value;
	    }
	}
	return bestVal;
    }
}
