import weiss.util.Comparator;
import weiss.util.Collection;
import weiss.util.Collections;
import weiss.util.Iterator;
import weiss.util.List;
import weiss.util.Set;
import weiss.util.ArrayList;
import weiss.util.LinkedList;
import weiss.util.TreeSet;
import weiss.util.HashSet;

class SimpleStudent1 implements Comparable<SimpleStudent1> {
	private String name;
	private int id;
	// the following could be a Set
	private List<Book> books = new ArrayList<Book>();

	public SimpleStudent1(String n, int i) {
		name = n;
		id = i;
	}

	public void addBook(long isbn, String title) {
		books.add(new Book(isbn, title));
	}

	public boolean hasBook(long isbn) {
		return books.contains(new Book(isbn));
	}

	public Book findBook(long isbn) {
		for (Book book : books) {
			if (book.getIsbn() == isbn)
				return book;
		}
		return null;
	}

	public String toString() {
		return name + " " + id;
	}

	public boolean equals(Object rhs) {
		if (rhs == null || getClass() != rhs.getClass())
			return false;

		SimpleStudent1 other = (SimpleStudent1) rhs;
		return name.equals(other.name);
	}

	public int compareTo(SimpleStudent1 other) {
		return name.compareTo(other.name);
	}

	public int hashCode() {
		return name.hashCode();
	}

	private class Book {
	    // Variables are private so that they won't be accessible
		private long isbn;
		private String title;

		public Book(long isbn, String title) {
			this.isbn = isbn;
			this.title = title;
		}

		public Book(long isbn) {
			this.isbn = isbn;
			this.title = null;
		}

		public long getIsbn() {
			return isbn;
		}

		public String getTitle() {
			return title;
		}

		public String getOwner() {
			return name;         // ref to outer class field
		}

		// needed for contains call inside hasBook--
		public boolean equals(Object rhs) {
			if (rhs == null || getClass() != rhs.getClass())
				return false;

			Book other = (Book) rhs;
			return isbn == other.isbn;
		}

		// should be supplied if equals is supplied--
		public int hashCode() {
			return new Long(isbn).hashCode();
		}
	}
}

